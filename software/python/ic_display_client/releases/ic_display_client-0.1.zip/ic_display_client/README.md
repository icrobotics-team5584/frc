# ic_display_client #
A Graphical Frontend for the nVidia Jetson and 5" 800x480 display.

**DEPENDENCIES**
Python 3 - Any version should work.
pygame for Python 3 - I've installed this through 'pip3 install pygame'
socket for Python 3 - This is for TCP communication. It should come installed by default.

