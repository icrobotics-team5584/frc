g++ main.cpp -o output -Wall -std=c++11  -L ./Linux/arm/ -lstdc++ -lntcore -pthread  -Iinclude/
